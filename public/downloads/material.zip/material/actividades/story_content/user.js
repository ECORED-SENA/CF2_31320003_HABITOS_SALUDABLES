function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5YOPMtuUac1":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

